#include <Wire.h>
#include <LovyanGFX.hpp>
#include <Adafruit_MLX90640.h>
#include <Adafruit_Sensor.h>      
#include <Adafruit_VL53L0X.h>     
#include <Adafruit_MPU6050.h>     // MPU6050 RESTORED

// --- 1. PIN DEFINITIONS ---
#define MOTOR_LEFT   15
#define MOTOR_CENTER 16
#define MOTOR_RIGHT  17

// --- DISPLAY DRIVER CONFIGURATION (100% UNTOUCHED) ---
class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ILI9341     _panel_instance;
  lgfx::Bus_SPI          _bus_instance; 

public:
  LGFX(void) {
    { 
      auto cfg = _bus_instance.config();
      cfg.spi_host = SPI2_HOST;     
      cfg.spi_mode = 0;             
      cfg.freq_write = 40000000;    
      cfg.freq_read  = 16000000;    
      cfg.pin_sclk = 12;            
      cfg.pin_mosi = 11;            
      cfg.pin_miso = 13;            
      cfg.pin_dc   = 10;            
      _bus_instance.config(cfg);
      _panel_instance.setBus(&_bus_instance);
    }
    { 
      auto cfg = _panel_instance.config();
      cfg.pin_cs           = 14;    
      cfg.pin_rst          = 9;     
      cfg.panel_width      = 240; 
      cfg.panel_height     = 320; 
      cfg.offset_x         = 0;
      cfg.offset_y         = 0;
      cfg.offset_rotation  = 0;
      cfg.readable         = false;
      cfg.invert           = false; 
      cfg.rgb_order        = true; 
      cfg.dlen_16bit       = false; 
      cfg.bus_shared       = false; 
      _panel_instance.config(cfg);
      setPanel(&_panel_instance);
    }
  }
};
LGFX tft; 

// --- SENSORS ---
Adafruit_MLX90640 mlx;
Adafruit_VL53L0X lox = Adafruit_VL53L0X(); 
Adafruit_MPU6050 mpu; // MPU6050 OBJECT ADDED

// --- RTOS SHARED MEMORY & MUTEX ---
TaskHandle_t Core0_VisionTask;
SemaphoreHandle_t dataMutex; 

// Shared Spatial Variables
float globalMaxT = -100.0;
bool globalTargetL = false;
bool globalTargetC = false;
bool globalTargetR = false;
float globalFrame[768]; 

LGFX_Sprite thermalSprite(&tft);
unsigned long lastTextUpdate = 0;

// =========================================================================
// --- CORE 0: 35°C SPATIAL VISION ENGINE ---
// =========================================================================
void core0Process(void * pvParameters) {
  for(;;) {
    float tempFrame[768];
    if (mlx.getFrame(tempFrame) == 0) {
        
      float maxT = -100.0; 
      bool tL = false, tC = false, tR = false;
      
      for (int i = 0; i < 768; i++) {
        if (tempFrame[i] > maxT) maxT = tempFrame[i];
        
        // 35.0C THRESHOLD
        if (tempFrame[i] >= 35.0) { 
          int x = i % 32; 
          if (x <= 10) tL = true;
          else if (x <= 20) tC = true;
          else tR = true;
        }
      }

      if (xSemaphoreTake(dataMutex, portMAX_DELAY)) {
        globalTargetL = tL;
        globalTargetC = tC;
        globalTargetR = tR;
        globalMaxT = maxT;
        memcpy(globalFrame, tempFrame, sizeof(globalFrame));
        xSemaphoreGive(dataMutex);
      }
    }
    vTaskDelay(5 / portTICK_PERIOD_MS); 
  }
}

// =========================================================================
// --- SYSTEM SETUP ---
// =========================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);

  dataMutex = xSemaphoreCreateMutex();

  pinMode(MOTOR_LEFT, OUTPUT); digitalWrite(MOTOR_LEFT, LOW);
  pinMode(MOTOR_CENTER, OUTPUT); digitalWrite(MOTOR_CENTER, LOW);
  pinMode(MOTOR_RIGHT, OUTPUT); digitalWrite(MOTOR_RIGHT, LOW);

  // --- FAST NAVIGATION BUS (Wire 1: Pins 6, 7) ---
  Wire1.begin(6, 7); 
  Wire1.setClock(400000); 
  Wire1.setTimeOut(20);   
  delay(500);
  
  // INIT ToF
  if (!lox.begin(0x29, false, &Wire1)) { Serial.println("ToF: FAIL"); } 
  else { Serial.println("ToF: OK"); lox.setMeasurementTimingBudgetMicroSeconds(20000); }

  // INIT MPU6050 ON WIRE1
  if (!mpu.begin(0x68, &Wire1)) { Serial.println("MPU: FAIL"); } 
  else { 
    Serial.println("MPU: OK"); 
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ); // Smooths out jitter
  }

  // --- THERMAL BUS (Wire 0: Pins 4, 5) ---
  Wire.begin(4, 5); 
  Wire.setClock(400000); 
  
  if (!mlx.begin(MLX90640_I2CADDR_DEFAULT, &Wire)) { 
    Serial.println("MLX90640 Failure!"); 
    while (1) delay(10); 
  }
  
  mlx.setMode(MLX90640_CHESS);
  mlx.setResolution(MLX90640_ADC_18BIT);
  mlx.setRefreshRate(MLX90640_16_HZ); 

  tft.init();
  tft.setRotation(5); 
  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_CYAN); tft.setFont(&fonts::Font2); 
  tft.setCursor(10, 10); tft.print("// TACTICAL HUD // [POSTURE ACTIVE]");
  tft.drawRect(5, 230, 230, 85, TFT_CYAN); 
  tft.drawRect(7, 232, 226, 81, TFT_DARKCYAN); 
  tft.setCursor(15, 245); tft.print("MAX TEMP:");
  tft.setCursor(15, 270); tft.print("ZONE:");

  // High-Resolution Sprite
  thermalSprite.createSprite(224, 168);

  xTaskCreatePinnedToCore(core0Process, "VisionTask", 10000, NULL, 1, &Core0_VisionTask, 0);
}

// =========================================================================
// --- CORE 1: DISPLAY, NAV, & HAPTICS ENGINE ---
// =========================================================================
void loop() {
  unsigned long currentMillis = millis(); 
  
  // 1. READ NAVIGATION SENSORS (ToF + MPU)
  VL53L0X_RangingMeasurementData_t measure;
  sensors_event_t a, g, temp_mpu;
  int16_t dist = 9999;

  // Read MPU6050 Pitch
  mpu.getEvent(&a, &g, &temp_mpu);
  float pitch = (atan2(a.acceleration.y, a.acceleration.z) * 180.0) / PI;

  // Read ToF Distance
  lox.rangingTest(&measure, false); 
  if (measure.RangeStatus != 4) {
    dist = measure.RangeMilliMeter;
    if (dist > 2000 || dist < 20) dist = 2000; 
  }
  
  // THE POSTURE FILTER: Only warn about walls if looking straight ahead (-25 to +25 degrees)
  bool lookingForward = (pitch > -25.0 && pitch < 25.0);
  bool wallDetected = (lookingForward && dist < 800 && dist > 50);

  // 2. FETCH SPATIAL DATA FROM CORE 0 
  static float localFrame[768] = {0}; 
  static float localMaxT = 0;
  static bool locL = false, locC = false, locR = false; 
  
  if (xSemaphoreTake(dataMutex, 5 / portTICK_PERIOD_MS)) {
    locL = globalTargetL;
    locC = globalTargetC;
    locR = globalTargetR;
    localMaxT = globalMaxT;
    memcpy(localFrame, globalFrame, sizeof(localFrame));
    xSemaphoreGive(dataMutex);
  }

  bool anyThermalTarget = (locL || locC || locR);

  // 3. 3D SPATIAL MOTOR LOGIC (POWER-SAFE)
  int pwrL = 0, pwrC = 0, pwrR = 0;

  if (wallDetected && anyThermalTarget) {
    int pulse = (currentMillis % 200 < 100) ? 200 : 0; 
    analogWrite(MOTOR_LEFT, locL ? pulse : 0);
    analogWrite(MOTOR_CENTER, locC ? pulse : 0);
    analogWrite(MOTOR_RIGHT, locR ? pulse : 0);
  } else if (wallDetected) {
    int pulse = (currentMillis % 500 < 250) ? 140 : 0; 
    analogWrite(MOTOR_LEFT, pulse);
    analogWrite(MOTOR_CENTER, pulse);
    analogWrite(MOTOR_RIGHT, pulse);
  } else if (anyThermalTarget) {
    analogWrite(MOTOR_LEFT, locL ? 120 : 0);
    analogWrite(MOTOR_CENTER, locC ? 120 : 0);
    analogWrite(MOTOR_RIGHT, locR ? 120 : 0);
  } else {
    analogWrite(MOTOR_LEFT, 0);
    analogWrite(MOTOR_CENTER, 0);
    analogWrite(MOTOR_RIGHT, 0);
  }

  // 4. TEXT HUD
  if (currentMillis - lastTextUpdate > 250) {
    lastTextUpdate = currentMillis;
    tft.setFont(&fonts::Font2); 
    
    tft.setTextColor(TFT_CYAN, TFT_BLACK); 
    tft.setCursor(120, 245); tft.printf("%04.1f C", localMaxT); 
    
    tft.setCursor(70, 270);
    if (locL) tft.setTextColor(TFT_RED, TFT_BLACK); else tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.print("[L] ");
    
    if (locC) tft.setTextColor(TFT_RED, TFT_BLACK); else tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.print("[C] ");
    
    if (locR) tft.setTextColor(TFT_RED, TFT_BLACK); else tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.print("[R]");

    tft.setCursor(15, 295);
    if (wallDetected) {
      tft.setTextColor(TFT_ORANGE, TFT_BLACK); tft.print("WARNING: WALL AHEAD   ");
    } else {
      tft.setTextColor(TFT_DARKGREEN, TFT_BLACK); tft.print("PATH CLEAR            ");
    }
  }

  // -------------------------------------------------------------------------
  // 5. BILINEAR INTERPOLATION ENGINE (SMOOTH HIGH-RES RENDER)
  // -------------------------------------------------------------------------
  float minT = 20.0; 
  float maxT_disp = 35.0; 
  
  thermalSprite.startWrite(); 
  for (int y = 0; y < 168; y++) {
    for (int x = 0; x < 224; x++) {
      
      float srcX = x / 7.0f;
      float srcY = y / 7.0f;
      
      int x1 = (int)srcX;
      int y1 = (int)srcY;
      int x2 = x1 + 1; if (x2 > 31) x2 = 31;
      int y2 = y1 + 1; if (y2 > 23) y2 = 23;
      
      float fx = srcX - x1;
      float fy = srcY - y1;
      
      float t1 = localFrame[y1 * 32 + x1] * (1.0f - fx) + localFrame[y1 * 32 + x2] * fx;
      float t2 = localFrame[y2 * 32 + x1] * (1.0f - fx) + localFrame[y2 * 32 + x2] * fx;
      float temp = t1 * (1.0f - fy) + t2 * fy;
      
      float ratio = (temp - minT) / (maxT_disp - minT);
      if (ratio < 0.0f) ratio = 0.0f;
      if (ratio > 1.0f) ratio = 1.0f;
      
      int r = 255 * ratio;
      int b = 255 * (1.0f - ratio);
      
      thermalSprite.drawPixel(x, y, thermalSprite.color565(r, 0, b)); 
    }
  }
  thermalSprite.endWrite(); 
  
  tft.waitDisplay();
  thermalSprite.pushSprite(8, 40); 
  // -------------------------------------------------------------------------

  if (currentMillis % 250 < 15) { 
    Serial.printf("Pitch:%.1f | Dist:%dmm | Wall:%d\n", pitch, dist, wallDetected);
  }

  delay(10); 
}